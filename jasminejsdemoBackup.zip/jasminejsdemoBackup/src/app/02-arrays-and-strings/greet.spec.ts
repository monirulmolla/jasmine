import {greet} from './greet';

describe('greet', () => {
  it('should include name in the message', () => {
    // expect(greet('Monirul')).toBe('Welcome Monirul');
    expect(greet('Monirul')).toContain('Monirul');
  });
});
