let currentVal = 0;
let nullValue = null;
let undefinedValue;

describe('toBeDefined', function (){

  it('Example of  toBeDefined', function (){
    expect(currentVal).toBeDefined();
  });

});


describe('toBeUndefine', function (){

  it('Example of toBeUndefine()', function (){
    expect(undefinedValue).toBeUndefined();
  });

});


describe('toBeNull', function (){

  it('Example of toBeNull()', function (){
    expect(nullValue).toBeNull();
  });

});
