
export function compute(number) {
  if (number < 0) {
    return false;
  }
  return true;
}
