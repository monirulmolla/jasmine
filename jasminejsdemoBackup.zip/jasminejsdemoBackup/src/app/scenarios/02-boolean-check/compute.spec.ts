import {compute} from './compute';
describe('compute', () => {

  it('should return true if it is positive', () => {
    const result = compute(1);
    expect(result).toBeTruthy();
  });

  it('should return false if input is negative', () => {
    const result = compute(-1);
    expect(result).toBeFalsy();
  });
})
