let currentval = 0;

beforeEach(function(){
  currentval = 5;
});
afterEach(function(){
  //currentVal = 10;
});
describe('beforeEach', function(){

  it('first call', function(){
    expect(currentval).toEqual(5);
  });
  /*
  it('second call', function(){
    expect(currentVal).toEqual(5);
  });*/

});



