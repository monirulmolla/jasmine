let Person = function() {};

Person.prototype.sayHelloWorld = function(dict){
  return dict.hello() + ' ' + dict.world();
};

let Dictionary = function() {};

Dictionary.prototype.hello = function() {
  return 'hello';
};

Dictionary.prototype.world = function() {
  return 'world';
};

describe('Example Of jasmine Spy using spyOn()', function() {

  it('uses the dictionary to say "hello world', function() {
    const dictionary = new Dictionary;
    const person = new Person;

    spyOn(dictionary, 'hello');  // replace hello function with a spy
    spyOn(dictionary, 'world'); // replace world function with another spy

    person.sayHelloWorld(dictionary);
    expect(dictionary.hello).toHaveBeenCalled();
    // not possible without first spy

    expect(dictionary.world).toHaveBeenCalled();
    // not possible withoutsecond spy
  });

});



describe('Example Of jasmine Spy using Create Spy', function() {

  it('can have a spy function', function() {
    const person = new Person();
    person.getName11 = jasmine.createSpy('Name spy');
   // person.getName11();
    expect(person.getName11).toHaveBeenCalled();
  });

});
