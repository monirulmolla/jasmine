export function myException() {
  throw new Error();
}
