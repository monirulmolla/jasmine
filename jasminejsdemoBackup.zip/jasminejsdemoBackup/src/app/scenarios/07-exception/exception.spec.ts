import {myException} from './exception';

describe('Error Block', function() {

  it ('Hey this will throw an Error', function() {
    expect(myException).toThrow();
  });

});
