describe('toBeNaN', function (){

  it('Example of toBeNaN()', function (){
    expect(0 / 0).toBeNaN();
  });

});
