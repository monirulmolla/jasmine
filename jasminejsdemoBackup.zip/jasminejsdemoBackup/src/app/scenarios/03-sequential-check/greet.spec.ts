import {greet} from './greet';

describe('greet', () => {
  it('should contain name in the message', () => {
    expect(greet('John')).toContain('John');
  });
});

describe('Different Methods of Expect Block', function (){

  it('Example of toBeCloseTo()', function (){
    expect(12.34).toBeCloseTo(12.3, 1);
  });

});


describe('Different Methods of Expect Block', function (){
  it('Example of toMatch()', function (){
    expect('www.jasmine.com').toMatch(/com/);
  });
});
