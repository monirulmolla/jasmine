let myValue =8;

describe('toBeGreaterThan', function (){

  it('Example of  toBeGreaterThan()', function (){
    expect(myValue).toBeGreaterThan(5);
  });

});

describe('toBeLessThan', function (){

  it ('Example of toBeLessThan()' , function (){
    expect(myValue).toBeLessThan(10);
  });

});
