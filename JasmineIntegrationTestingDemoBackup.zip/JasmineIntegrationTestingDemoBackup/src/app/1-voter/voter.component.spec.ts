import {TestBed, ComponentFixture} from '@angular/core/testing';
import { VoterComponent } from './voter.component';
import {By} from '@angular/platform-browser';
import * as testing from "selenium-webdriver/testing";

describe('VoterComponent', () => {
  let component: VoterComponent;
  let fixture: ComponentFixture<VoterComponent>;
  beforeEach(() => {
    // declare the component
    TestBed.configureTestingModule({
      declarations: [VoterComponent]
    });

    // create instance of the component
    fixture = TestBed.createComponent(VoterComponent);
    component = fixture.componentInstance;
    //fixture.nativeElement
    //fixture.debugElement
  });

  it('it should render total values', () => {
    component.othersVote = 20;
    component.myVote = 1;
    fixture.detectChanges();
   let de =  fixture.debugElement.query(By.css('.vote-count'));
   let el : HTMLElement = de.nativeElement;
   expect(el.innerText).toContain(21);
  });

  it('it should highlighted the upvote element if voted', () => {
    component.myVote = 1;
    fixture.detectChanges();
    let de =  fixture.debugElement.query(By.css('.glyphicon-menu-up'));
    expect(de.classes['highlighted']).toBeTruthy();
  });
});
